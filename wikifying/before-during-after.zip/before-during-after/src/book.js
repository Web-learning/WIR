const themeToggle =
  document.getElementById("themeToggle");

const fontUp =
  document.getElementById("fontUp");

const fontDown =
  document.getElementById("fontDown");

const bookText =
  document.getElementById("bookText");


/* ==============================
   DARK MODE
============================== */

themeToggle.addEventListener("click", () => {

  document.body.classList.toggle("dark");

  const dark =
    document.body.classList.contains("dark");

  themeToggle.textContent =
    dark
      ? "☀️ Light mode"
      : "🌙 Dark mode";

});


/* ==============================
   COLLAPSIBLE SECTIONS
============================== */


/* ==============================
   FONT SIZE
============================== */

let fontSize = 20;


fontUp.addEventListener("click", () => {

  fontSize =
    Math.min(fontSize + 1, 24);

  bookText.style.setProperty(
    "--font-size",
    `${fontSize}px`
  );

});


fontDown.addEventListener("click", () => {

  fontSize =
    Math.max(fontSize - 1, 13);

  bookText.style.setProperty(
    "--font-size",
    `${fontSize}px`
  );

});


/* ==============================
   ACTIVE SECTION
============================== */

const links =
  document.querySelectorAll(
    ".sidebar nav a"
  );


links.forEach(link => {

  link.addEventListener("click", () => {

    links.forEach(item =>
      item.classList.remove("active")
    );

    link.classList.add("active");

  });

});


document.addEventListener("DOMContentLoaded", loadBook);


async function loadBook() {

  try {

    const response = await fetch("book.json");

    if (!response.ok) {
      throw new Error(
        `Could not load book.json: ${response.status}`
      );
    }

    const book = await response.json();

    renderMeta(book);
    renderNavigation(book);
    renderContents(book);
    renderHome(book);
    renderChapters(book);
    renderBottomNavigation(book);
    renderFooter(book);

  } catch (error) {

    console.error("Book loading error:", error);

    document.getElementById("bookText").innerHTML = `
      <div class="notice notice-yellow">
        <strong>Unable to load book</strong>
        <p>
          ${error.message}
        </p>
      </div>
    `;
  }
}


/* -----------------------------------
   META
----------------------------------- */

function renderMeta(book) {

  document.getElementById("bookLogo").textContent =
    book.meta.logo || "";

  document.getElementById("bookLogoTitle").textContent =
    book.meta.logoTitle || "";

  document.getElementById("bookEyebrow").textContent =
    book.meta.eyebrow || "";

  document.getElementById("bookTitle").textContent =
    book.meta.title || "";

  document.getElementById("bookSubtitle").textContent =
    book.meta.subtitle || "";

  document.title =
    book.meta.title || "Book";
}


/* -----------------------------------
   SIDEBAR NAVIGATION
----------------------------------- */

function renderNavigation(book) {

  const nav =
    document.getElementById("mainNavigation");

  nav.innerHTML = "";

  book.navigation.forEach(item => {

    const link = document.createElement("a");

    link.href = item.href;
    link.textContent = item.text;

    if (item.active) {
      link.classList.add("active");
    }

    nav.appendChild(link);

  });
}


/* -----------------------------------
   TABLE OF CONTENTS
----------------------------------- */

function renderContents(book) {

  const toc =
    document.getElementById("tableOfContents");

  toc.innerHTML = "";

  book.contents.forEach(item => {

    const li = document.createElement("li");

    li.innerHTML = `
      <a href="${item.href}">
        ${item.text}
      </a>
    `;

    if (item.children) {

      const nested = document.createElement("ol");

      item.children.forEach(child => {

        const childLi =
          document.createElement("li");

        childLi.innerHTML = `
          <a href="${child.href}">
            ${child.text}
          </a>
        `;

        nested.appendChild(childLi);

      });

      li.appendChild(nested);
    }

    toc.appendChild(li);

  });
}


/* -----------------------------------
   HOME
----------------------------------- */

function renderHome(book) {

  const home = book.home;

  document.getElementById("homeLabel").textContent =
    home.label || "";

  document.getElementById("homeTitle").textContent =
    home.title || "";

  document.getElementById("homeContent").innerHTML =
    renderBlocks(home.content || []);
}


/* -----------------------------------
   CHAPTERS
----------------------------------- */

function renderChapters(book) {

  const container =
    document.getElementById("chapters");

  container.innerHTML = "";

  book.chapters.forEach(chapter => {

    const section =
      document.createElement("section");

    section.id = chapter.id;

    section.innerHTML = `
      <h2>
        ${chapter.number}. ${chapter.title}
      </h2>

      ${renderBlocks(chapter.content || [])}
    `;

    container.appendChild(section);

  });
}


/* -----------------------------------
   CONTENT BLOCKS
----------------------------------- */

function renderBlocks(blocks) {

  return blocks.map(block => {

    switch (block.type) {

      case "paragraph":

        return `
          <p>
            ${block.html || ""}
          </p>
        `;


      case "heading":

        return `
          <h${block.level || 3}
              ${block.id ? `id="${block.id}"` : ""}>
            ${block.text || ""}
          </h${block.level || 3}>
        `;


      case "image":

        return `
          <figure class="book-image">

            <img
              src="${block.src}"
              alt="${block.alt || ""}"
              ${block.width ? `width="${block.width}"` : ""}
              ${block.height ? `height="${block.height}"` : ""}
            >

            ${
              block.caption
                ? `<figcaption>${block.caption}</figcaption>`
                : ""
            }

          </figure>
        `;


      case "notice":

        return `
          <div class="notice notice-${block.style || "blue"}">

            <strong>
              ${block.title || ""}
            </strong>

            <p>
              ${block.html || ""}
            </p>

          </div>
        `;


      case "infobox":

        return `
          <aside class="infobox">

            <div class="infobox-title">
              ${block.title || ""}
            </div>

            ${block.rows.map(row => `
              <div class="infobox-row">

                <span>
                  ${row.label}
                </span>

                <strong>
                  ${row.value}
                </strong>

              </div>
            `).join("")}

          </aside>
        `;


      case "colour-strip":

        return `
          <div class="colour-strip">

            ${block.colours.map(color => `
              <span
                style="background:${color}">
              </span>
            `).join("")}

          </div>
        `;


      case "collapsible":

        return `
          <div class="collapsible">

            <button class="collapse-title">

              <span>
                ${block.title || ""}
              </span>

              <span>
                +
              </span>

            </button>

            <div class="collapse-content">

              ${renderBlocks(block.content || [])}

            </div>

          </div>
        `;


      default:

        console.warn(
          "Unknown block type:",
          block.type
        );

        return "";

    }

  }).join("");
}


/* -----------------------------------
   BOTTOM NAVIGATION
----------------------------------- */

function renderBottomNavigation(book) {

  const nav = book.bottomNavigation;

  document.getElementById(
    "bottomNavigationTitle"
  ).textContent = nav.title || "";

  const links =
    document.getElementById(
      "bottomNavigationLinks"
    );

  links.innerHTML = "";

  nav.links.forEach(item => {

    const link =
      document.createElement("a");

    link.href = item.href;
    link.textContent = item.text;

    links.appendChild(link);

  });
}


/* -----------------------------------
   FOOTER
----------------------------------- */

function renderFooter(book) {

  document.getElementById("footerText").innerHTML =
    book.footer.html || "";
}
