# Before, during, after

A Pen created on CodePen.

Original URL: [https://codepen.io/editor/Web-learning-the-bold/pen/01a0aa89-b603-749f-8243-19d12f87fcc0](https://codepen.io/editor/Web-learning-the-bold/pen/01a0aa89-b603-749f-8243-19d12f87fcc0).

